package com.rsvp.exception;

public class AdminLoginException extends Exception{

	private static final long serialVersionUID = 1L;

	public AdminLoginException(String message, Throwable cause) {
		super(message, cause);
	}
	
	

}
